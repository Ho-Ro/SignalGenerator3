# SimpleSH1106

This is a standalone library that contains both graphics functions
and the OLED SH1106 driver library.

Operates with I2C bus

It is written in plain C.
